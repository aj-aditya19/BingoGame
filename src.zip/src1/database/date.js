import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "./User.js";

dotenv.config({ path: "../../.env" });

await mongoose.connect(process.env.MONGODB_URI);

const emails = [
  "ajeetjayswal71@gmail.com",
  "monakh3105@gmail.com",
  "jaiswaltushar911@gmail.com",
  "ayusheeettk@gmail.com",
  "ayushiarora576@gmail.com",
  "bartwalsumit860@gmail.com",
  "shahidd2802@gmail.com",
  "jeevanrana9587@gmail.com",
  "priyanshudubey821@gmail.com",
  "tamannakhanna8177@gmail.com",
  "sj1930054@gmail.com",
  "omikasingh4636stella@gmail.com",
  "vishnoirupanshi7@gmail.com",
  "ranjeetkarak03@gmail.com",
  "harshitbhattthc@gmail.com",
  "nidaerub3@gmail.com",
  "mohitrana45340@gmail.com",
];

function randomDate(start, end) {
  return new Date(
    start.getTime() + Math.random() * (end.getTime() - start.getTime()),
  );
}

const users = await User.find({
  email: { $in: emails },
});

for (const user of users) {
  const createdAt = randomDate(new Date("2026-01-01"), new Date("2026-05-15"));

  const lastLogin = randomDate(
    new Date(createdAt.getTime() + 5 * 24 * 60 * 60 * 1000), // at least 5 days later
    new Date("2026-07-05"),
  );

  const updatedAt = new Date(
    lastLogin.getTime() + Math.floor(Math.random() * 6 * 60 * 60 * 1000),
  );

  await User.updateOne(
    { _id: user._id },
    {
      $set: {
        createdAt,
        lastLogin,
        updatedAt,
      },
    },
    {
      timestamps: false,
    },
  );

  console.log(`${user.email} updated`);
}

console.log("Only the 17 seeded users were updated.");

await mongoose.connection.close();
